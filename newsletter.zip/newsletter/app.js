const express = require('express');
const request = require('request');
const bodyParser = require('body-parser');
const path = require('path');

const app=express();
//body parser
app.use(bodyParser.urlencoded({extended:true}));

//folder
app.use(express.static(path.join(__dirname, 'new')));

//email newsletter
app.post('/emailsub',(req,res)=> {
    // console.log(req.body)
    const uemail=req.body['email'];
    if(!uemail){
        res.redirect('/fail.html');
        return;
    }
    console.log(`Email getted is ${uemail}`);
    //data
    const data={
        members:[
            {
                email_address: uemail,
                status: 'subscribe'
            }
        ]
    }

    const postData= JSON.stringify(data);
    console.log(postData)
    //request
    const options= {
        // url: 'https://$API_SERVER.api.mailchimp.com/3.0/lists  https://us17.admin.mailchimp.com/lists/settings/defaults?id=1068594'
        url: 'https://us17.admin.mailchimp.com/lists/members/add?id=1068594',
        method:'POST',
        headers: {
            Authorization: 'auth 45db9ae65872c92319eff7bb5f3e1d18-us17'
        },
        body: postData
    }
    request(options,(err,response,body)=>{
        if(err){
            res.redirect('/fail.html')
        }else{
            if(response.statusCode== 200){
                res.redirect('/sent.html')
            }
        }
    })    
    //valid
    res.send('i got u');
});

const PORT=process.env.PORT || 5000;

app.listen(PORT,console.log(`Server Started On ${PORT}`));